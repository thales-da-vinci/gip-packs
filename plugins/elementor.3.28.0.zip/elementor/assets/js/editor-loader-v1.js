/*! elementor - v3.28.0 - 17-03-2025 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!*******************************************************!*\
  !*** ../core/editor/loader/v1/js/editor-loader-v1.js ***!
  \*******************************************************/


window.elementor.start();
/******/ })()
;
//# sourceMappingURL=editor-loader-v1.js.map