<?php
// Proteção por senha
define('GIP_OPT_PASS', 'nutralle2024');

if (!isset($_GET['pass']) || $_GET['pass'] !== GIP_OPT_PASS) {
    die('Acesso negado. Use ?pass=nutralle2024 na URL.');
}

require_once __DIR__ . '/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';

echo "<h2>🧹 Otimizando Plugins</h2><pre>";

$to_deactivate = [
    'elementskit-lite/elementskit-lite.php',
    'wp-file-manager/file_folder_manager.php',
    'svg-support/svg-support.php',
];

foreach ($to_deactivate as $plugin) {
    if (is_plugin_active($plugin)) {
        deactivate_plugins($plugin);
        echo "🔧 Plugin desativado: {$plugin}\n";
    }
}

echo "\n✅ Otimização concluída.\n</pre>";
?>
