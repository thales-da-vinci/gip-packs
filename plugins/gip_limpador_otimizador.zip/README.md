
# GIP Diagnóstico e Otimização WordPress

## Scripts incluídos:

1. **limpar_shortcodes_elementor.php**
   - Remove shortcodes [elementor] inválidos de posts/páginas.

2. **otimizar_plugins.php**
   - Desativa plugins redundantes ou perigosos.

## Uso:

1. Envie os arquivos para a raiz do seu WordPress.
2. Acesse via navegador:
   - https://seudominio.com.br/limpar_shortcodes_elementor.php?pass=nutralle2024
   - https://seudominio.com.br/otimizar_plugins.php?pass=nutralle2024
3. Após executar, exclua os scripts por segurança.
