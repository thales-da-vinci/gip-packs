<?php
// Proteção básica por senha
define('GIP_CLEAN_PASS', 'nutralle2024');

if (!isset($_GET['pass']) || $_GET['pass'] !== GIP_CLEAN_PASS) {
    die('Acesso negado. Use ?pass=nutralle2024 na URL.');
}

require_once __DIR__ . '/wp-load.php';

echo "<h2>🧹 Limpando Shortcodes [elementor] de Posts/Páginas</h2><pre>";

global $wpdb;
$posts = $wpdb->get_results("SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('page','post')");

$contador = 0;

foreach ($posts as $post) {
    if (strpos($post->post_content, '[elementor') !== false) {
        $original = $post->post_content;
        $limpo = preg_replace('/\[elementor[^\]]*\]/i', '', $original);

        if ($limpo !== $original) {
            wp_update_post([
                'ID' => $post->ID,
                'post_content' => $limpo,
            ]);
            $contador++;
            echo "✔️ Post ID {$post->ID} ({$post->post_title}) limpo.\n";
        }
    }
}

echo "\n✅ Concluído. {$contador} posts/páginas atualizados.\n</pre>";
?>
